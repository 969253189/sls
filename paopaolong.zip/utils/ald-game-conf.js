exports.app_key = "93a15e897e8e9c33264deb3196edc062"; //请在此行填写从阿拉丁后台获取的appkey
exports.getLocation = false; //默认不获取用户坐标位置